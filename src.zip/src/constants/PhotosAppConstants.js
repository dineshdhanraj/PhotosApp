export const ListDetails = 'ListData';
export const ErrorDetails = 'Error';
export const LoadingDetails = 'Loading';
export const NewItemDetails = 'ItemDetails';
export const VisibleDetails = 'IndicatorVisible';
