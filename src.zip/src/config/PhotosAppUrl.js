export default function PhotoPaginationUrl() {
  return 'https://jsonplaceholder.typicode.com/photos';
}
